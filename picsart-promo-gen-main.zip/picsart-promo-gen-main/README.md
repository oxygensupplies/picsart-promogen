
# How to use?

Put capsolver key and set threads in config.json.
Put proxies in proxies.txt leave empty if you want to use proxyless
Run main.py using 
